/**
 * AgriStack Helper - Extension Popup Script
 * 
 * Features:
 * - Direct connection to Production Cloud Backend
 * - Full multi-user login / registration with popup notifications
 * - Live wallet balance display & Cashfree Payment Gateway recharge drawer
 * - 1-Click Gurmukhi HarfBuzz shaped Farmer ID Card generation & auto-download
 * - Automatic background recharge verification & instant balance sync
 */
(function () {
    "use strict";

    const DEFAULT_SERVER_URL = "http://127.0.0.1:5001";
    const CARD_FEE = 15;

    let currentServerUrl = DEFAULT_SERVER_URL;
    let walletId = "";
    let walletToken = "";
    let currentBalance = 0.0;
    let isServerConnected = false;
    let isRechargePolling = false;
    let currentCheckoutWindowId = null;

    document.addEventListener("DOMContentLoaded", function () {
        // UI Elements
        const statusDiv = document.getElementById("status");
        const statusTextEl = document.getElementById("statusText");
        const backendBadge = document.getElementById("backendBadge");
        const walletBalDisplay = document.getElementById("walletBalDisplay");
        const cardsRemainingBadge = document.getElementById("cardsRemainingBadge");
        const cardUserMobileVal = document.getElementById("cardUserMobileVal");

        const syncBtn = document.getElementById("syncBtn");
        const refreshBtn = document.getElementById("refreshBtn");
        const logoutBtn = document.getElementById("logoutBtn");

        const rechargeBtn = document.getElementById("rechargeBtn");
        const closeRechargeBtn = document.getElementById("closeRechargeBtn");
        const rechargeDrawer = document.getElementById("rechargeDrawer");
        const rechargeAmountInput = document.getElementById("rechargeAmountInput");
        const submitRechargeBtn = document.getElementById("submitRechargeBtn");
        const chipBtns = document.querySelectorAll(".chip-btn");

        const stateSelect = document.getElementById("stateSelect");
        const stateAutoBadge = document.getElementById("stateAutoBadge");

        const aadhaarInput = document.getElementById("aadhaarInput");
        const generateBtn = document.getElementById("generateBtn");

        const transactionsBtn = document.getElementById("transactionsBtn");
        const activityList = document.getElementById("activityList");
        const activityArrow = document.getElementById("activityArrow");

        const authUI = document.getElementById("authUI");
        const mainUI = document.getElementById("mainUI");
        const loginBox = document.getElementById("loginBox");
        const registerBox = document.getElementById("registerBox");
        const loginPhone = document.getElementById("loginPhone");
        const loginPass = document.getElementById("loginPass");
        const btnLogin = document.getElementById("btnLogin");
        const showRegister = document.getElementById("showRegister");
        const regPhone = document.getElementById("regPhone");
        const regPass = document.getElementById("regPass");
        const btnRegister = document.getElementById("btnRegister");
        const showLogin = document.getElementById("showLogin");
        const authStatusLogin = document.getElementById("authStatusLogin");
        const authStatusReg = document.getElementById("authStatusReg");
        const toast = document.getElementById("toast");

        // Toast popup notification helper
        let toastTimeout = null;
        function showToast(message, duration) {
            if (!toast) return;
            toast.textContent = message;
            toast.classList.add("show");
            if (toastTimeout) clearTimeout(toastTimeout);
            toastTimeout = setTimeout(function () {
                toast.classList.remove("show");
            }, duration || 2800);
        }

        // Status bar text helper
        function setStatus(message, type) {
            if (statusTextEl) {
                statusTextEl.textContent = message;
            } else if (statusDiv) {
                statusDiv.textContent = message;
            }
            if (statusDiv) {
                if (type === "success") {
                    statusDiv.className = "refresh-status";
                } else if (type === "error") {
                    statusDiv.className = "refresh-status status-error";
                } else if (type === "warning") {
                    statusDiv.className = "refresh-status status-warning";
                } else {
                    statusDiv.className = "refresh-status";
                }
            }
        }

        // Online badge helper
        function setBadge(state, label, tooltip) {
            if (!backendBadge) return;
            let cleanLabel = label;
            if (state === "online") cleanLabel = "Online";
            else if (state === "paused") cleanLabel = "Paused";
            else if (state === "offline") cleanLabel = "Offline";
            else cleanLabel = label.replace(/^[^\w\s]+/, '').trim() || label;

            backendBadge.innerHTML = '<span class="online-dot"></span> <span>' + cleanLabel + '</span>';
            backendBadge.title = tooltip || label;
            backendBadge.className = "online " + (state === "online" ? "" : state);
        }

        // Display cached balance at start
        try {
            const cachedBal = localStorage.getItem("agristack_wallet_balance") || "0.00";
            if (walletBalDisplay && cachedBal) {
                walletBalDisplay.textContent = parseFloat(cachedBal).toFixed(2);
                if (cardsRemainingBadge) {
                    const rem = Math.floor(parseFloat(cachedBal) / CARD_FEE);
                    cardsRemainingBadge.textContent = rem + (rem === 1 ? " card" : " cards");
                }
            }
        } catch (e) {}

        // Load Stored Wallet Credentials
        const localStoredId = localStorage.getItem("agristack_wallet_id");
        const localStoredToken = localStorage.getItem("agristack_wallet_token");

        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get([
                "wallet_id",
                "wallet_token"
            ], function (res) {
                walletId = res.wallet_id || localStoredId || "";
                walletToken = res.wallet_token || localStoredToken || "";
                initWallet();
            });
        } else {
            walletId = localStoredId || "";
            walletToken = localStoredToken || "";
            initWallet();
        }

        function updateUserMobileDisplays() {
            if (cardUserMobileVal) cardUserMobileVal.textContent = walletId || "...";
        }

        function handleUnauthorizedSession(message) {
            walletId = "";
            walletToken = "";
            try {
                localStorage.removeItem("agristack_wallet_id");
                localStorage.removeItem("agristack_wallet_token");
                if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.remove(["wallet_id", "wallet_token"]);
                }
            } catch(e) {}
            if (authUI) authUI.style.display = "block";
            if (mainUI) mainUI.style.display = "none";
            setBadge("online", "Online", "Connected to Server");
            if (authStatusLogin) {
                authStatusLogin.style.display = "block";
                authStatusLogin.textContent = message || "Session expired. Please log in again.";
                authStatusLogin.className = "auth-status-box status-error";
            }
        }

        // Initialize or Sync Wallet
        function initWallet(isLoginAction, isRegisterAction) {
            if (!walletId || !walletToken) {
                if (authUI) authUI.style.display = "block";
                if (mainUI) mainUI.style.display = "none";
                setBadge("online", "Online", "Connected to Server");
                return Promise.resolve(false);
            }
            updateUserMobileDisplays();
            if (authUI) authUI.style.display = "none";
            if (mainUI) mainUI.style.display = "block";

            setBadge("online", "Online", "Connecting to server...");
            setStatus("Connecting to server...", "normal");

            const controller = new AbortController();
            const timeoutId = setTimeout(function () { controller.abort(); }, 35000);

            return fetch(currentServerUrl + "/api/wallet/balance", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    wallet_id: walletId,
                    wallet_token: walletToken
                }),
                signal: controller.signal
            })
            .then(function (res) {
                clearTimeout(timeoutId);
                if (res.status === 401) {
                    handleUnauthorizedSession("Session expired or invalid login token.");
                    throw new Error("AUTH_EXPIRED");
                }
                if (!res.ok) throw new Error("HTTP " + res.status);
                return res.json();
            })
            .then(function (data) {
                if (data.status === "success") {
                    isServerConnected = true;
                    currentBalance = Number(data.balance) || 0.0;

                    if (walletBalDisplay) {
                        walletBalDisplay.textContent = currentBalance.toFixed(2);
                        if (cardsRemainingBadge) {
                            const rem = Math.floor(currentBalance / CARD_FEE);
                            cardsRemainingBadge.textContent = rem + (rem === 1 ? " card" : " cards");
                        }
                    }
                    try { localStorage.setItem("agristack_wallet_balance", currentBalance.toFixed(2)); } catch(e) {}

                    setBadge("online", "Online", "Connected");
                    setStatus("Balance refreshed: " + data.formatted_balance, "success");
                    
                    if (isRegisterAction) {
                        showToast("🎉 Account created successfully! Wallet active.", 3500);
                    } else if (isLoginAction) {
                        showToast("🎉 Welcome back! Login successful as " + walletId, 3200);
                    }

                    if (data.recent_transactions && activityList) {
                        renderActivity(data.recent_transactions);
                    }
                    return true;
                } else {
                    throw new Error(data.error || "Balance query failed");
                }
            })
            .catch(function (err) {
                clearTimeout(timeoutId);
                if (err.message === "AUTH_EXPIRED") return;
                isServerConnected = false;
                setBadge("offline", "Server Offline", "Unable to connect to backend");
                setStatus("Server offline: " + err.message, "error");
            });
        }

        // Auth switch tabs
        if (showRegister) {
            showRegister.addEventListener("click", function () {
                if (loginBox) loginBox.style.display = "none";
                if (registerBox) registerBox.style.display = "block";
            });
        }
        if (showLogin) {
            showLogin.addEventListener("click", function () {
                if (registerBox) registerBox.style.display = "none";
                if (loginBox) loginBox.style.display = "block";
            });
        }

        function handleAuth(url, phone, pass, statusEl, isRegister) {
            if (!phone || phone.length !== 10 || !/^\d+$/.test(phone)) {
                if (statusEl) {
                    statusEl.style.display = "block";
                    statusEl.textContent = "Please enter a valid 10-digit mobile number.";
                    statusEl.className = "auth-status-box status-error";
                }
                showToast("⚠️ Enter valid 10-digit mobile");
                return;
            }
            if (!pass || pass.length !== 5) {
                if (statusEl) {
                    statusEl.style.display = "block";
                    statusEl.textContent = "Password must be exactly 5 digits.";
                    statusEl.className = "auth-status-box status-error";
                }
                showToast("⚠️ Password must be 5 digits");
                return;
            }

            if (statusEl) {
                statusEl.style.display = "block";
                statusEl.textContent = isRegister ? "Creating your wallet..." : "Logging in...";
                statusEl.className = "auth-status-box status-warning";
            }
            showToast(isRegister ? "Creating your account..." : "Logging in...", 2000);

            fetch(currentServerUrl + url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ mobile_number: phone, password: pass })
            })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (data.status === "success") {
                    walletId = data.wallet_id;
                    walletToken = data.wallet_token;
                    currentBalance = Number(data.balance) || 0.0;

                    localStorage.setItem("agristack_wallet_id", walletId);
                    localStorage.setItem("agristack_wallet_token", walletToken);
                    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
                        chrome.storage.local.set({ wallet_id: walletId, wallet_token: walletToken });
                    }

                    updateUserMobileDisplays();
                    initWallet(!isRegister, isRegister);
                } else {
                    if (statusEl) {
                        statusEl.textContent = data.error || "Authentication failed";
                        statusEl.className = "auth-status-box status-error";
                    }
                    showToast("❌ " + (data.error || "Authentication failed"), 3200);
                }
            })
            .catch(function (err) {
                if (statusEl) {
                    statusEl.textContent = err.message;
                    statusEl.className = "auth-status-box status-error";
                }
                showToast("❌ Connection error: " + err.message, 3200);
            });
        }

        if (btnLogin) {
            btnLogin.addEventListener("click", function () {
                handleAuth("/api/wallet/login", loginPhone.value.trim(), loginPass.value.trim(), authStatusLogin, false);
            });
        }
        if (btnRegister) {
            btnRegister.addEventListener("click", function () {
                handleAuth("/api/wallet/register", regPhone.value.trim(), regPass.value.trim(), authStatusReg, true);
            });
        }

        if (logoutBtn) {
            logoutBtn.addEventListener("click", function () {
                walletId = "";
                walletToken = "";
                localStorage.removeItem("agristack_wallet_id");
                localStorage.removeItem("agristack_wallet_token");
                if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.remove(["wallet_id", "wallet_token"]);
                }
                showToast("👋 Logged out successfully", 2500);
                initWallet();
            });
        }

        // Refresh Live Wallet Balance
        function refreshBalance(silent) {
            if (!walletId || !walletToken || !isServerConnected) {
                initWallet();
                return;
            }
            if (!silent) {
                setStatus("Refreshing balance...", "normal");
                showToast("Refreshing balance...");
            }

            const controller = new AbortController();
            const timeoutId = setTimeout(function () { controller.abort(); }, 8000);

            fetch(currentServerUrl + "/api/wallet/balance", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    wallet_id: walletId,
                    wallet_token: walletToken
                }),
                signal: controller.signal
            })
            .then(function (res) {
                clearTimeout(timeoutId);
                if (res.status === 401) {
                    handleUnauthorizedSession("Session expired or invalid login token.");
                    throw new Error("AUTH_EXPIRED");
                }
                if (!res.ok) throw new Error("Status " + res.status);
                return res.json();
            })
            .then(function (data) {
                if (data.status === "success") {
                    isServerConnected = true;
                    if (data.wallet_id) walletId = data.wallet_id;
                    if (data.wallet_token) walletToken = data.wallet_token;
                    currentBalance = Number(data.balance) || 0.0;
                    updateWalletUI(data);

                    setBadge("online", "Online", "Connected to Render Cloud");
                    if (!silent) {
                        setStatus("Balance refreshed: " + data.formatted_balance, "success");
                        showToast("Balance: " + data.formatted_balance);
                    }
                }
            })
            .catch(function (err) {
                clearTimeout(timeoutId);
                if (err.message === "AUTH_EXPIRED") return;
                isServerConnected = false;
                setBadge("offline", "Server Offline", "Server unreachable");
                setStatus("Server offline: " + err.message, "error");
            });
        }

        function updateWalletUI(data) {
            if (data.balance !== undefined && !isNaN(Number(data.balance))) {
                currentBalance = Number(data.balance);
            }
            if (walletBalDisplay) {
                walletBalDisplay.textContent = currentBalance.toFixed(2);
            }
            if (cardsRemainingBadge) {
                const remaining = Math.floor(currentBalance / CARD_FEE);
                cardsRemainingBadge.textContent = remaining + (remaining === 1 ? " card" : " cards");
            }
            try {
                localStorage.setItem("agristack_wallet_balance", currentBalance.toFixed(2));
                if (walletId) localStorage.setItem("agristack_wallet_id", walletId);
                if (walletToken) localStorage.setItem("agristack_wallet_token", walletToken);
            } catch (e) {}
            if (data.recent_transactions && activityList) {
                renderActivity(data.recent_transactions);
            }
        }

        function renderActivity(txns) {
            if (!activityList) return;
            if (!txns || txns.length === 0) {
                activityList.innerHTML = '<div style="text-align:center; color:#94A3B8; padding:8px;">No recent transactions</div>';
                return;
            }
            let html = '';
            txns.forEach(function (t) {
                const isRecharge = t.txn_type === 'RECHARGE' || t.amount > 0;
                const sign = isRecharge ? '+' : '';
                const amtClass = isRecharge ? 'txn-plus' : 'txn-minus';
                const desc = t.description || (isRecharge ? 'Wallet Top-up' : 'Farmer Card Generation');
                const timeStr = t.created_at ? t.created_at.split(' ')[1] || '' : '';

                html += '<div class="activity-item">' +
                    '<div>' +
                    '<div style="font-weight:700; color:#1E293B;">' + desc + '</div>' +
                    '<div style="font-size:10px; color:#94A3B8;">' + (t.reference_id || '') + ' ' + timeStr + '</div>' +
                    '</div>' +
                    '<div class="' + amtClass + '">' + sign + '₹' + Math.abs(t.amount).toFixed(2) + '</div>' +
                    '</div>';
            });
            activityList.innerHTML = html;
        }

        // Sync & Refresh Button click handlers
        if (syncBtn) {
            syncBtn.addEventListener("click", function () {
                refreshBalance(false);
            });
        }
        if (refreshBtn) {
            refreshBtn.addEventListener("click", function () {
                refreshBalance(false);
            });
        }

        // Recharge Drawer & Presets
        if (rechargeBtn) {
            rechargeBtn.addEventListener("click", function () {
                if (!rechargeDrawer) return;
                const isVisible = rechargeDrawer.style.display === "block";
                rechargeDrawer.style.display = isVisible ? "none" : "block";
            });
        }

        if (closeRechargeBtn) {
            closeRechargeBtn.addEventListener("click", function () {
                if (rechargeDrawer) rechargeDrawer.style.display = "none";
            });
        }

        chipBtns.forEach(function (btn) {
            btn.addEventListener("click", function () {
                chipBtns.forEach(function (c) { c.classList.remove("active"); });
                btn.classList.add("active");
                const amt = btn.getAttribute("data-amt");
                if (rechargeAmountInput) rechargeAmountInput.value = amt;
            });
        });

        // Submit Wallet Recharge (Cashfree PG)
        if (submitRechargeBtn) {
            submitRechargeBtn.addEventListener("click", function () {
                if (!isServerConnected) {
                    setStatus("Backend server is offline. Please check connection.", "error");
                    showToast("⚠️ Server is offline");
                    return;
                }

                const amount = parseFloat(rechargeAmountInput ? rechargeAmountInput.value : 0);
                if (isNaN(amount) || amount < 100) {
                    setStatus("Please enter a valid amount (minimum ₹100).", "error");
                    showToast("⚠️ Minimum recharge amount is ₹100");
                    return;
                }

                setStatus("Opening Cashfree Payment Gateway...", "normal");
                showToast("Opening Payment Gateway...");
                submitRechargeBtn.disabled = true;

                const finalPhone = walletId || "9876543210";

                fetch(currentServerUrl + "/api/wallet/recharge", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        wallet_id: walletId,
                        wallet_token: walletToken,
                        amount: amount,
                        session_id: "EXT_" + Date.now(),
                        customer_phone: finalPhone
                    })
                })
                .then(function (res) {
                    if (!res.ok) {
                        return res.json().catch(function () { return {}; }).then(function (err) {
                            throw new Error(err.error || ("Server error (" + res.status + ")"));
                        });
                    }
                    return res.json();
                })
                .then(function (data) {
                    if (data.status !== "success") {
                        throw new Error(data.error || "Failed to create recharge order.");
                    }

                    const checkoutUrl = data.full_checkout_url || (currentServerUrl + data.checkout_url);

                    // Open hosted checkout in popup window or tab
                    if (typeof chrome !== "undefined" && chrome.windows && chrome.windows.create) {
                        chrome.windows.create({
                            url: checkoutUrl,
                            type: "popup",
                            width: 460,
                            height: 720,
                            focused: true
                        }, function (newWin) {
                            if (newWin && newWin.id) {
                                currentCheckoutWindowId = newWin.id;
                            }
                        });
                    } else if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
                        chrome.tabs.create({ url: checkoutUrl });
                    } else {
                        window.open(checkoutUrl, "_blank");
                    }

                    setStatus("Checkout opened. Complete payment to add funds.", "success");
                    showToast("💳 Complete payment in checkout window");
                    pollForRecharge(data.order_id);
                })
                .catch(function (err) {
                    setStatus("Error: " + err.message, "error");
                    showToast("❌ " + err.message);
                })
                .finally(function () {
                    submitRechargeBtn.disabled = false;
                });
            });
        }

        // Poll for recharge confirmation in background
        function pollForRecharge(orderId) {
            if (isRechargePolling) return;
            isRechargePolling = true;

            let attempts = 0;
            const pollTimer = setInterval(function () {
                attempts++;
                if (attempts > 100) {
                    clearInterval(pollTimer);
                    isRechargePolling = false;
                    return;
                }

                fetch(currentServerUrl + "/api/wallet/verify_recharge", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ order_id: orderId, wallet_id: walletId, wallet_token: walletToken })
                })
                .then(function (r) { return r.json(); })
                .then(function (vData) {
                    if (vData.status === "success" && vData.order_status === "PAID") {
                        clearInterval(pollTimer);
                        isRechargePolling = false;
                        currentBalance = Number(vData.new_balance) || (currentBalance + Number(vData.amount || 0));
                        updateWalletUI(vData);
                        if (rechargeDrawer) rechargeDrawer.style.display = "none";
                        const addedAmt = Number(vData.amount || 0).toFixed(2);
                        setStatus("Recharge Successful! +₹" + addedAmt + " added.", "success");
                        showToast("🎉 Recharge of ₹" + addedAmt + " Successful!", 3500);
                        refreshBalance(false);

                        // Auto-close checkout popup window after payment confirmation
                        if (currentCheckoutWindowId && typeof chrome !== "undefined" && chrome.windows && chrome.windows.remove) {
                            setTimeout(function () {
                                chrome.windows.remove(currentCheckoutWindowId, function () {
                                    if (chrome.runtime.lastError) {}
                                });
                                currentCheckoutWindowId = null;
                            }, 1500);
                        }
                    }
                })
                .catch(function () {});
            }, 1800);
        }

        // State detection and mapping helper
        function detectStateFromUrl(url) {
            if (!url) return null;
            const domainMatch = url.match(/https?:\/\/([a-z]{2})fr\.agristack\.gov\.in/i);
            if (domainMatch && domainMatch[1]) {
                return domainMatch[1].toUpperCase();
            }
            const pathMatch = url.match(/farmer-registry-([a-z]{2})/i);
            if (pathMatch && pathMatch[1]) {
                return pathMatch[1].toUpperCase();
            }
            return null;
        }

        function applyDetectedState(code, isAuto) {
            if (!stateSelect || !code) return;
            const upper = code.toUpperCase();
            const optionExists = Array.from(stateSelect.options).some(function (opt) { return opt.value === upper; });
            if (optionExists) {
                stateSelect.value = upper;
                if (stateAutoBadge) {
                    stateAutoBadge.textContent = isAuto ? ("Auto: " + upper) : "Selected";
                    stateAutoBadge.style.background = isAuto ? "#ecfdf5" : "#f1f5f9";
                    stateAutoBadge.style.color = isAuto ? "#047857" : "#475569";
                    stateAutoBadge.style.borderColor = isAuto ? "#d1fae5" : "#cbd5e1";
                }
            }
        }

        // Check active tab immediately for state detection
        if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.query) {
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                const activeTab = tabs && tabs[0];
                if (activeTab && activeTab.url) {
                    const detected = detectStateFromUrl(activeTab.url);
                    if (detected) {
                        applyDetectedState(detected, true);
                        return;
                    }
                }
                const savedState = localStorage.getItem("agristack_selected_state");
                if (savedState) {
                    applyDetectedState(savedState, false);
                }
            });
        }

        if (stateSelect) {
            stateSelect.addEventListener("change", function () {
                const val = stateSelect.value;
                if (stateAutoBadge) {
                    stateAutoBadge.textContent = "Selected";
                    stateAutoBadge.style.background = "#f1f5f9";
                    stateAutoBadge.style.color = "#475569";
                    stateAutoBadge.style.borderColor = "#cbd5e1";
                }
                try { localStorage.setItem("agristack_selected_state", val); } catch (e) {}
            });
        }

        // Auto-format Inputs
        if (loginPhone) {
            loginPhone.addEventListener("input", function () {
                this.value = this.value.replace(/\D/g, "").slice(0, 10);
            });
        }
        if (regPhone) {
            regPhone.addEventListener("input", function () {
                this.value = this.value.replace(/\D/g, "").slice(0, 10);
            });
        }
        if (loginPass) {
            loginPass.addEventListener("input", function () {
                this.value = this.value.slice(0, 5);
            });
        }
        if (regPass) {
            regPass.addEventListener("input", function () {
                this.value = this.value.slice(0, 5);
            });
        }
        if (aadhaarInput) {
            aadhaarInput.addEventListener("input", function () {
                this.value = this.value.replace(/\D/g, "").slice(0, 12);
            });
        }

        // Extract Farmer Details from Active Portal Tab
        function getActiveTabHtml() {
            return new Promise(function (resolve, reject) {
                if (typeof chrome === "undefined" || !chrome.tabs || !chrome.tabs.query) {
                    return reject(new Error("Browser tabs API unavailable."));
                }
                chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    const activeTab = tabs && tabs[0];
                    if (!activeTab || !activeTab.id) {
                        return reject(new Error("No active browser tab found."));
                    }
                    if (activeTab.url && (activeTab.url.startsWith("chrome://") || activeTab.url.startsWith("chrome-extension://") || activeTab.url.startsWith("edge://") || activeTab.url.startsWith("about:"))) {
                        return reject(new Error("Please switch to the AgriStack farmer registry webpage tab first."));
                    }
                    
                    // Auto-sync state from URL if detected
                    if (activeTab.url) {
                        const detected = detectStateFromUrl(activeTab.url);
                        if (detected) {
                            applyDetectedState(detected, true);
                        }
                    }

                    chrome.scripting.executeScript({
                        target: { tabId: activeTab.id },
                        func: function () {
                            return document.documentElement.outerHTML;
                        }
                    }, function (results) {
                        if (chrome.runtime.lastError) {
                            return reject(new Error(chrome.runtime.lastError.message));
                        }
                        if (!results || !results[0] || !results[0].result) {
                            return reject(new Error("Failed to read webpage content. Ensure you are on the verified details page."));
                        }
                        resolve({ tabId: activeTab.id, html: results[0].result, tabUrl: activeTab.url });
                    });
                });
            });
        }

        // 1-Click Instant Card Generation
        if (generateBtn) {
            generateBtn.addEventListener("click", function () {
                if (!isServerConnected) {
                    setStatus("Server offline. Please verify backend connection.", "error");
                    showToast("⚠️ Server is offline");
                    return;
                }

                if (currentBalance < CARD_FEE) {
                    setStatus("Insufficient balance (₹" + currentBalance.toFixed(2) + "). Need ₹" + CARD_FEE + ".", "warning");
                    showToast("⚠️ Insufficient balance (₹" + currentBalance.toFixed(2) + "). Please recharge.", 3200);
                    if (rechargeDrawer) rechargeDrawer.style.display = "block";
                    return;
                }

                const aadhaarValue = aadhaarInput ? aadhaarInput.value.trim() : "";
                if (aadhaarValue.length !== 0 && aadhaarValue.length !== 12) {
                    showToast("⚠️ Please enter a valid 12-digit Aadhaar");
                    if (aadhaarInput) aadhaarInput.focus();
                    return;
                }

                const selectedState = stateSelect ? stateSelect.value : "PB";

                setStatus("Reading farmer registry data from active tab...", "normal");
                showToast("Generating Farmer ID Card...", 2500);
                generateBtn.disabled = true;

                getActiveTabHtml()
                    .then(function (pageData) {
                        setStatus("Shaping " + selectedState + " regional text & generating card PDF...", "normal");

                        const payload = {
                            wallet_id: walletId,
                            wallet_token: walletToken,
                            html: pageData.html,
                            aadhaar: aadhaarValue,
                            state_code: selectedState
                        };

                        return fetch(currentServerUrl + "/api/card/generate", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(payload)
                        }).then(function (res) {
                            if (!res.ok) {
                                return res.json().catch(function () { return {}; }).then(function (err) {
                                    if (res.status === 402) {
                                        if (rechargeDrawer) rechargeDrawer.style.display = "block";
                                        throw new Error(err.error || "Insufficient wallet balance. Please recharge.");
                                    }
                                    throw new Error(err.error || ("Server error (" + res.status + ")"));
                                });
                            }
                            return res.json();
                        });
                    })
                    .then(function (cardData) {
                        if (cardData.status !== "success") {
                            throw new Error(cardData.error || "Card generation failed.");
                        }

                        currentBalance = Number(cardData.wallet_balance) || 0.0;
                        updateWalletUI(cardData);

                        const downloadUrl = cardData.download_url.startsWith("http")
                            ? cardData.download_url
                            : (currentServerUrl + cardData.download_url);

                        const filename = "Farmer_Card_" + (cardData.farmer_id || "Verified") + ".pdf";

                        // Trigger automatic PDF download in browser
                        if (typeof chrome !== "undefined" && chrome.downloads && chrome.downloads.download) {
                            chrome.downloads.download({
                                url: downloadUrl,
                                filename: filename,
                                saveAs: false
                            }, function () {
                                if (chrome.runtime.lastError) {
                                    window.open(downloadUrl, "_blank");
                                }
                            });
                        } else {
                            window.open(downloadUrl, "_blank");
                        }

                        setStatus("Card generated! Downloaded: " + filename + " (-₹" + CARD_FEE + ")", "success");
                        showToast("✅ Card Downloaded! (-₹" + CARD_FEE + ")", 3500);
                        refreshBalance(true);
                    })
                    .catch(function (err) {
                        setStatus("Generation failed: " + err.message, "error");
                        showToast("❌ " + err.message, 3500);
                    })
                    .finally(function () {
                        generateBtn.disabled = false;
                    });
            });
        }

        // Transactions Accordion Toggle
        if (transactionsBtn) {
            transactionsBtn.addEventListener("click", function () {
                if (!activityList) return;
                const isOpen = activityList.style.display === "block";
                activityList.style.display = isOpen ? "none" : "block";
                if (activityArrow) {
                    activityArrow.style.transform = isOpen ? "rotate(0deg)" : "rotate(90deg)";
                }
                if (!isOpen) {
                    refreshBalance(true);
                }
            });
        }

        // Auto-refresh balance on window focus
        window.addEventListener("focus", function () {
            refreshBalance(true);
        });
    });
})();
